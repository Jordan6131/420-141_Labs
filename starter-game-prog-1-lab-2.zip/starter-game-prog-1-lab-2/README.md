# Game Programming 1 - Lab 2

This template repository is the starter project for Game Programming 1 Lab 2. Written in Java/Stride using Greenfoot.

### Question(s)

Please take a look at the attached PDF and source folder.
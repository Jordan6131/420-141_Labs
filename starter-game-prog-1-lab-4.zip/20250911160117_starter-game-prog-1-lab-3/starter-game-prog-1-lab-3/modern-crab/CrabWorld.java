// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import greenfoot.*;

/**
 * Write a description of class CrabWorld here.
 * @author (your name) @version (a version number or a date)
 */
public class CrabWorld extends World
{

    /* (World, Actor, GreenfootImage, Greenfoot and MouseInfo)*/

    /**
     * Constructor for objects of class CrabWorld.
     */
    public CrabWorld()
    {
        super(560, 560, 1);
        prepare();
        Greenfoot.setSpeed(40);
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Crab crab =  new Crab();
        addObject(crab, 177, 361);
        Worm worm =  new Worm();
        addObject(worm, 481, 97);
        Worm worm2 =  new Worm();
        addObject(worm2, 249, 105);
        Worm worm3 =  new Worm();
        addObject(worm3, 439, 243);
        Worm worm4 =  new Worm();
        addObject(worm4, 268, 222);
        Worm worm5 =  new Worm();
        addObject(worm5, 76, 128);
        Worm worm6 =  new Worm();
        addObject(worm6, 433, 365);
        Worm worm7 =  new Worm();
        addObject(worm7, 305, 482);
        Worm worm8 =  new Worm();
        addObject(worm8, 31, 263);
        Worm worm9 =  new Worm();
        addObject(worm9, 89, 475);
        Worm worm10 =  new Worm();
        addObject(worm10, 468, 455);
        Worm worm11 =  new Worm();
        addObject(worm11, 406, 78);
        Lobster lobster =  new Lobster();
        addObject(lobster, 398, 146);
        worm6.setLocation(431, 366);
        removeObject(worm6);
        worm10.setLocation(457, 452);
        removeObject(worm10);
        worm9.setLocation(279, 350);
        removeObject(worm7);
        removeObject(worm3);
        removeObject(worm);
        removeObject(worm11);
        removeObject(worm2);
        removeObject(worm5);
        removeObject(worm8);
        removeObject(worm4);
    }
}
